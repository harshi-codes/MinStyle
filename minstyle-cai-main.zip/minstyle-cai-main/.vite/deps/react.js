import {
  require_react
} from "./chunk-E55NSNTN.js";
import "./chunk-4MBMRILA.js";
export default require_react();
//# sourceMappingURL=react.js.map
