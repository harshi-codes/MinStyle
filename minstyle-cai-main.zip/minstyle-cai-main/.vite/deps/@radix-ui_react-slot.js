import {
  Root,
  Slot,
  Slottable
} from "./chunk-74SYZI33.js";
import "./chunk-T6PWRRVS.js";
import "./chunk-E55NSNTN.js";
import "./chunk-4MBMRILA.js";
export {
  Root,
  Slot,
  Slottable
};
//# sourceMappingURL=@radix-ui_react-slot.js.map
