import {
  clsx,
  clsx_default
} from "./chunk-KDVGFZWC.js";
import "./chunk-4MBMRILA.js";
export {
  clsx,
  clsx_default as default
};
//# sourceMappingURL=clsx.js.map
